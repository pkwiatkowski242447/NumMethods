import menu

if __name__ == '__main__':
    menu.menu_start()
